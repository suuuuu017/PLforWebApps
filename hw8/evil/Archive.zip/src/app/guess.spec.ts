import { Guess } from './guess';

describe('Guess', () => {
  it('should create an instance', () => {
    expect(new Guess()).toBeTruthy();
  });
});
