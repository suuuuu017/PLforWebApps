export class Guess {
  constructor(
    public g: string,
    public rightLetter: number,
    public rightPosition: number,
    public type:string){

  }
}
